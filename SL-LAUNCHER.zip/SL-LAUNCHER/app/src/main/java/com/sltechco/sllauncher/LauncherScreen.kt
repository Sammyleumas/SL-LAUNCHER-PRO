package com.sltechco.sllauncher

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import android.appwidget.AppWidgetProviderInfo
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

fun Modifier.glass(radius: Int = 24): Modifier = this
    .clip(RoundedCornerShape(radius.dp))
    .background(Aurora.GlassFill)
    .border(1.dp, Aurora.GlassBorder, RoundedCornerShape(radius.dp))

@Composable
fun LauncherScreen(widgets: WidgetController) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var drawer by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.Default) { AppRepo.load(ctx) } }

    fun launch(a: AppItem) {
        ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let { ctx.startActivity(it) }
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0x666558E8), Color(0x3321C9B7), Color(0x8817152E))))
            .pointerInput(Unit) { detectVerticalDragGestures { _, d -> if (d < -30f) drawer = true } }
    ) {
        val list = apps
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (list == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Aurora.Teal)
                else LazyVerticalGrid(GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item(span = { GridItemSpan(maxLineSpan) }) { ClockBlock() }
                    item(span = { GridItemSpan(maxLineSpan) }) { WidgetsSection(widgets) { picker = true } }
                    if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { Text("No launchable apps found", color = Color.White) }
                    items(list.drop(3).take(16), key = { it.pkg }) { AppCell(it, ::launch) }
                }
            }
            Row(
                Modifier.fillMaxWidth().glass(32).padding(12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
            ) {
                list?.take(3)?.forEach { AppCell(it, ::launch, showLabel = false) }
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Aurora.Violet).clickable { drawer = true },
                    contentAlignment = Alignment.Center
                ) { GridDots() }
            }
        }
        if (picker) WidgetPicker(widgets, onPick = { picker = false; widgets.request(it) }, onDismiss = { picker = false })
        AnimatedVisibility(drawer, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            Drawer(apps.orEmpty(), onClose = { drawer = false }, onLaunch = { drawer = false; launch(it) })
        }
    }
}

@Composable
fun ClockBlock() {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(15_000) } }
    Column(Modifier.fillMaxWidth().glass(28).padding(20.dp)) {
        Text(android.text.format.DateFormat.getTimeFormat(ctx).format(now), color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Light)
        Text(DateFormat.getDateInstance(DateFormat.FULL).format(now), color = Aurora.Amber, fontSize = 15.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(a: AppItem, onLaunch: (AppItem) -> Unit, showLabel: Boolean = true) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Column(
        Modifier.combinedClickable(onClick = { onLaunch(a) }, onLongClick = { menu = true }).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(a.icon, a.label, Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)))
        if (showLabel) Text(a.label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text("App info") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
            DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
        }
    }
}

@Composable
fun Drawer(apps: List<AppItem>, onClose: () -> Unit, onLaunch: (AppItem) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    BackHandler(onBack = onClose)
    val shown = remember(apps, q) { AppRepo.filterBy(apps, q) { it.label } }
    Column(Modifier.fillMaxSize().background(Color(0xE617152E)).systemBarsPadding().padding(16.dp)) {
        OutlinedTextField(
            q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search apps") },
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Aurora.Teal)
        )
        Spacer(Modifier.height(12.dp))
        if (shown.isEmpty()) Text("No apps match \"$q\"", color = Aurora.Amber)
        else LazyVerticalGrid(GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(shown, key = { it.pkg }) { AppCell(it, onLaunch) }
        }
    }
}

@Composable
fun GridDots() = Canvas(Modifier.size(22.dp)) {
    for (i in 0..2) for (j in 0..2)
        drawCircle(Color.White, size.width / 12f, Offset(size.width * (i * 2 + 1) / 6f, size.height * (j * 2 + 1) / 6f))
}

@Composable
fun WidgetsSection(c: WidgetController, onAdd: () -> Unit) {
    val msg = c.message.value
    LaunchedEffect(msg) { if (msg != null) { delay(3000); c.message.value = null } }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Widgets", color = Color.White, fontSize = 14.sp)
            IconButton(onClick = onAdd) { Icon(Icons.Default.Add, "Add widget", tint = Color.White) }
        }
        if (msg != null) Text(msg, color = Aurora.Amber, fontSize = 12.sp)
        if (c.ids.isEmpty()) Text("Tap + to add a widget from your installed apps", color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
        c.ids.toList().forEach { id -> key(id) { HostedWidget(c, id) { c.remove(id) } } ; Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
fun HostedWidget(c: WidgetController, id: Int, onRemove: () -> Unit) {
    val info = remember(id) { c.mgr.getAppWidgetInfo(id) }
    if (info == null) { LaunchedEffect(id) { onRemove() }; return }
    val ctx = LocalContext.current
    val h = with(LocalDensity.current) { info.minHeight.toDp() }.coerceIn(80.dp, 320.dp)
    Box(Modifier.fillMaxWidth().height(h).glass(20)) {
        AndroidView(factory = { c.host.createView(ctx, id, info) }, modifier = Modifier.fillMaxSize())
        IconButton(onClick = onRemove, modifier = Modifier.align(Alignment.TopEnd).size(36.dp)) {
            Icon(Icons.Default.Close, "Remove widget", tint = Color.White)
        }
    }
}

@Composable
fun WidgetPicker(c: WidgetController, onPick: (AppWidgetProviderInfo) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val list = remember { c.providers() }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Add widget") },
        text = {
            if (list.isEmpty()) Text("No widgets available on this device")
            else LazyColumn {
                items(list.size) { i ->
                    val p = list[i]
                    val icon = remember(p) { runCatching { p.loadIcon(ctx, 0).toBitmap(48, 48).asImageBitmap() }.getOrNull() }
                    Row(Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (icon != null) Image(icon, null, Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)))
                        Spacer(Modifier.width(12.dp))
                        Text(p.loadLabel(ctx.packageManager) ?: p.provider.packageName)
                    }
                }
            }
        }
    )
}
