package com.sltechco.sllauncher

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

object AppRepo {
    /** Lists launchable apps via launcher intent. Call off the main thread. */
    fun load(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(120, 120).asImageBitmap()) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun <T> filterBy(items: List<T>, q: String, label: (T) -> String) =
        if (q.isBlank()) items else items.filter { label(it).contains(q.trim(), ignoreCase = true) }
}
