package com.sltechco.sllauncher

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

/** Real Android widget hosting: bind, configure, persist IDs, restore, remove. */
class WidgetController(private val act: ComponentActivity) {
    val host = AppWidgetHost(act, HOST_ID)
    val mgr: AppWidgetManager = AppWidgetManager.getInstance(act)
    val ids = mutableStateListOf<Int>()
    val message = mutableStateOf<String?>(null)
    private val prefs = act.getSharedPreferences("widgets", Activity.MODE_PRIVATE)
    private var pending = -1

    init {
        prefs.getString("ids", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.forEach {
            if (mgr.getAppWidgetInfo(it) != null) ids.add(it) else host.deleteAppWidgetId(it) // provider uninstalled
        }
        save()
    }

    fun start() { try { host.startListening() } catch (_: Exception) { message.value = "Widgets could not start" } }
    fun stop() { try { host.stopListening() } catch (_: Exception) {} }

    fun providers(): List<AppWidgetProviderInfo> =
        mgr.installedProviders.sortedBy { it.loadLabel(act.packageManager).lowercase() }

    fun request(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId(); pending = id
        if (mgr.bindAppWidgetIdIfAllowed(id, info.provider)) configureOrAdd(id)
        else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            @Suppress("DEPRECATION") act.startActivityForResult(i, REQ_BIND)
        }
    }

    fun onResult(req: Int, res: Int) {
        if (req != REQ_BIND && req != REQ_CONFIG) return
        if (res == Activity.RESULT_OK) { if (req == REQ_BIND) configureOrAdd(pending) else add(pending) }
        else { host.deleteAppWidgetId(pending); message.value = "Widget was not added" }
    }

    private fun configureOrAdd(id: Int) {
        if (mgr.getAppWidgetInfo(id)?.configure != null)
            host.startAppWidgetConfigureActivityForResult(act, id, 0, REQ_CONFIG, null)
        else add(id)
    }

    private fun add(id: Int) { ids.add(id); save() }
    fun remove(id: Int) { host.deleteAppWidgetId(id); ids.remove(id); save() }
    private fun save() = prefs.edit().putString("ids", ids.joinToString(",")).apply()

    companion object { const val HOST_ID = 1024; const val REQ_BIND = 7001; const val REQ_CONFIG = 7002 }
}
