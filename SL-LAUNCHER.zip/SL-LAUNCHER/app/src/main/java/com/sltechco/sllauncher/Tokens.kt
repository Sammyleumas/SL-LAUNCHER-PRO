package com.sltechco.sllauncher

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Aurora {
    val Violet = Color(0xFF6558E8)
    val Teal = Color(0xFF21C9B7)
    val Amber = Color(0xFFFFB86B)
    val DeepViolet = Color(0xFF17152E)
    val Lavender = Color(0xFF292544)
    val LightBg = Color(0xFFF6F4FF)
    val InkLight = Color(0xFF201C36)
    val GlassFill = Color(0x2EFFFFFF)
    val GlassBorder = Color(0x40FFFFFF)
}

@Composable
fun SLTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme())
        darkColorScheme(primary = Aurora.Violet, secondary = Aurora.Teal, tertiary = Aurora.Amber, background = Aurora.DeepViolet, surface = Aurora.Lavender)
    else lightColorScheme(primary = Aurora.Violet, secondary = Aurora.Teal, tertiary = Aurora.Amber, background = Aurora.LightBg, surface = Color.White, onSurface = Aurora.InkLight)
    MaterialTheme(colorScheme = scheme, content = content)
}
