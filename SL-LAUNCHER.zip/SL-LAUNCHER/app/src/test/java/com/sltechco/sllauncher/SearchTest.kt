package com.sltechco.sllauncher

import org.junit.Assert.assertEquals
import org.junit.Test

class SearchTest {
    private val names = listOf("Camera", "Chrome", "Maps")
    @Test fun blankReturnsAll() = assertEquals(3, AppRepo.filterBy(names, " ") { it }.size)
    @Test fun matchIgnoresCase() = assertEquals(listOf("Chrome"), AppRepo.filterBy(names, "chr") { it })
    @Test fun noMatchIsEmpty() = assertEquals(0, AppRepo.filterBy(names, "zzz") { it }.size)
}
