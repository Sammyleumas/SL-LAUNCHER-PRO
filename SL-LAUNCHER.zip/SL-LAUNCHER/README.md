# SL-LAUNCHER (Phase 1 starter)
Developed by SL-TECHCO · `com.sltechco.sllauncher` · minSdk 26.

Included: real widget hosting (pick, configure, persist, remove), HOME intent, installed-app discovery, glass home screen, clock, dock, app drawer (search, swipe up), long-press App info / Uninstall, unit tests for search.
Not yet built: built-in widgets, folders, drag-and-drop, wallpaper picker, settings, backup (next phases).

## Build from your phone
1. Create a public GitHub repo named SL-LAUNCHER, upload these files (Add file > Upload files; keep folders).
2. Actions tab > "Build debug APK" > Run workflow.
3. Open the finished run > Artifacts > download SL-LAUNCHER-debug-apk, unzip, install the APK.
4. Press Home > choose SL-LAUNCHER > Always.

Status: not yet compiled or run on a device. If the build fails, send me the error log.
